<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ColegioController;
use App\Http\Controllers\PracticanteController;
use App\Http\Controllers\EditorialController;
use App\Http\Controllers\TalleristaController;
use App\Http\Controllers\AsocajaController;
use App\Http\Controllers\FilboArtistaController;
use App\Http\Controllers\PatrocinioController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
/*
Route::get('/colegio', function () {
    return view('colegio.index');
});
*/
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

/*Route::get('/colegio/create',[ColegioController::class,'create']);*/

Route::resource('colegio', ColegioController::class)->middleware('auth');
Route::resource('practicante', PracticanteController::class)->middleware('auth');
Route::resource('editorial', EditorialController::class)->middleware('auth');
Route::resource('tallerista', TalleristaController::class)->middleware('auth');
Route::resource('asocaja', AsocajaController::class)->middleware('auth');
Route::resource('filbo_artista',FilboArtistaController::class)->middleware('auth');
Route::resource('patrocinio', PatrocinioController::class)->middleware('auth');

