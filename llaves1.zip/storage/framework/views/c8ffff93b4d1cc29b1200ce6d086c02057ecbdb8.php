<?php $__env->startSection('content'); ?>

<head>
<link href="<?php echo e(asset('css/menu.css')); ?>" rel = "stylesheet">
</head>



<div class="container">
                <h1> Bases de datos disponibles </h1>

<div class="grid-container">

        <div class="grid-item"> <form action="http://localhost/llaves1/public/colegio/"> <button id="btn-tablero" type="submit">Colegios</button></form> </div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/filbo_artista"> <button id="btn-tablero" type="submit">Artistas filbo</button></form> </div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/practicante"> <button id="btn-tablero" type="submit">Practicantes </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/tallerista"> <button id="btn-tablero" type="submit">Talleristas </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/editorial"> <button id="btn-tablero" type="submit">Editoriales </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/asocaja"> <button id="btn-tablero" type="submit">Asocajas </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/patrocinio"> <button id="btn-tablero" type="submit">Patrocinios </button></form></div>
</div>



<div id="construccion" >
<h1> Bases de datos en Construccion: </h1>
<div class="grid-container">

        <div class="grid-item"> <form action="http://localhost/llaves1/public/colegio/"> <button id="btn-tableroC" type="submit">Asamblea</button></form> </div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/filbo_artista"> <button id="btn-tableroC" type="submit">Junta Directiva</button></form> </div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/practicante"> <button id="btn-tableroC" type="submit">Paola</button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/tallerista"> <button id="btn-tableroC" type="submit">Equipo Pombo </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/editorial"> <button id="btn-tableroC" type="submit">Mercadeo </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/asocaja"> <button id="btn-tableroC" type="submit">Otros </button></form></div>
        <div class="grid-item">  <form action="http://localhost/llaves1/public/patrocinio"> <button id="btn-tableroC" type="submit">Multinacionales </button></form></div>
</div>

</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\llaves1\resources\views/home.blade.php ENDPATH**/ ?>