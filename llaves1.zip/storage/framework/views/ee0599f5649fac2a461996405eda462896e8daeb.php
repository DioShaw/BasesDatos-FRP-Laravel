

<?php if(count($errors)>0): ?>

  <div class="alert alert-danger" role="alert">

  <ul>
       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <li> <?php echo e($error); ?> </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

      </ul>
  </div>

<?php endif; ?>


<div class="form-group">
<label for="nombre"> Colegio:</label>
<input type="text"class="form-control" name="nombre" value="<?php echo e(isset($colegio->Nombre)? $colegio->Nombre:''); ?>" id="nombre">
</div>

<div class="form-group">
<label for="Nit"> Nit:</label>
<input type="text" class="form-control" name="nit" value="<?php echo e(isset($colegio->Nit)?:''); ?>" id="nit">
</div>

<div class="form-group">
<label for="calidad"> calidad:</label>
<select class="form-control" name="calidad" >
  <option value="..."></option>
  <option value="value2">Distrital</option>
  <option value="value3">Privado</option>
  <option value="value3">ICBF</option>
</select>
</div>


<div class="form-group">

<label for="director"> director:</label>
<input type="text" class="form-control" name= "director" value="<?php echo e(isset($colegio->Director)?$colegio->Director:''); ?>">

<label for="contacto"> Contacto:</label>
<input type="text" class="form-control" name="contacto" value="<?php echo e(isset($colegio-> Contacto)?$colegio-> Contacto:''); ?>">

<label for="telefono"> telefono:</label>
<input type="text" class="form-control" name= "telefono" value= "<?php echo e(isset($colegio->Telefono)?$colegio->Telefono:''); ?>">
  
<label for="direccion"> direccion:</label>
<input type="text" class="form-control" name="direccion" value = "<?php echo e(isset($colegio->direccion)?$colegio->direccion:''); ?>">
  
<label for="correo"> Correo:</label>
<input type="text" class="form-control" name="correo" value="<?php echo e(isset($colegio->correo)?$colegio->correo:''); ?>">
 
<label for="ciudad"> Ciudad:</label>
<input type="text" class="form-control" name="ciudad" value = "<?php echo e(isset($colegio->Ciudad)?$colegio->Ciudad:''); ?>">

</div>

<input type="submit" class="btn btn-success" value="Enviar">



<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/colegio/form.blade.php ENDPATH**/ ?>