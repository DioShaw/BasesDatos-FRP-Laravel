


<?php $__env->startSection('content'); ?>

<div class="container">

<div id="formulario-editorial">
<form  action="<?php echo e(url('/editorial')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('editorial.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\llaves1\resources\views/editorial/create.blade.php ENDPATH**/ ?>