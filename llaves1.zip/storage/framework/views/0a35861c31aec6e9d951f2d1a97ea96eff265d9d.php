
<?php $__env->startSection('content'); ?>
<div class="container">
<div id="formulario-colegio">
<form  action="<?php echo e(url('/colegio')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo $__env->make('colegio.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\llaves1\resources\views/colegio/create.blade.php ENDPATH**/ ?>