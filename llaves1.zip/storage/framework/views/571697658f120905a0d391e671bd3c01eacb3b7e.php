

<?php if(count($errors)>0): ?>

<div class="alert alert-danger" role="alert">

<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

    </ul>
</div>

<?php endif; ?>


<div class="form-group">
<label for="nombre"> Editorial:</label>
<input type="text"class="form-control" name="nombre" value="<?php echo e(isset($editorial->Nombre)? $editorial->Nombre:''); ?>" id="nombre">
</div>

<div class="form-group">
<label for="Nit"> Nit:</label>
<input type="text" class="form-control" name="nit" value="<?php echo e(isset($editorial->Nit)?:''); ?>" id="nit">
</div>


<div class="form-group">

<label for="contacto"> Contacto:</label>
<input type="text" class="form-control" name= "contacto" value="<?php echo e(isset($editorial->Contacto)?$editorial->Contacto:''); ?>">


<label for="telefono"> telefono:</label>
<input type="text" class="form-control" name= "telefono" value= "<?php echo e(isset($editorial->Telefono)?$editorial->Telefono:''); ?>">

<label for="correo"> Correo:</label>
<input type="text" class="form-control" name="correo" value="<?php echo e(isset($editorial->Correo)?$editorial->Correo:''); ?>">

<label for="descuento"> Descuento:</label>
<input type="text" class="form-control" name="descuento" value = "<?php echo e(isset($editorial->Descuento)?$editorial->Descuento:''); ?>">

</div>

<input type="submit" class="btn btn-success" value="Enviar">

<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/editorial/form.blade.php ENDPATH**/ ?>