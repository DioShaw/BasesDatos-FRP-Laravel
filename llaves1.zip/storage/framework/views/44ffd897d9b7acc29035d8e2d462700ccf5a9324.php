<?php if(count($errors)>0): ?>

<div class="alert alert-danger" role="alert">
<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>                                                           
</div>

<?php endif; ?>


<div class="form-group">

<label for="Empresa"> Empresa:</label>
<input type="text" class="form-control"  name="Empresa" value="<?php echo e(isset($patrocinio->Empresa)? $patrocinio->Empresa:''); ?>" id="Empresa">
</div>

<div class="form-group">

<label for="nombre"> Nombres:</label>
<input type="text" class="form-control"  name="Nombre" value="<?php echo e(isset($patrocinio->Nombre)? $patrocinio->Nombre:''); ?>" id="Nombre">
</div>

<label for="Cargo"> Cargo:</label>
<input type="text" class="form-control"  name="Cargo" value="<?php echo e(isset($patrocinio->Cargo)?$patrocinio->Cargo:''); ?>" id="Cargo">
<br>
<label for="Tema"> Tema:</label>
<input type="text" class="form-control"  name= "Tema" value="<?php echo e(isset($patrocinio->Tema)?$patrocinio->Tema:''); ?>">
<br>
<label for="Contacto"> Contacto:</label>
<input type="text" class="form-control"  name="Contacto" value="<?php echo e(isset($patrocinio -> Contacto)?$patrocinio-> Contacto:''); ?>">
<br>
<label for="Correo"> Correo:</label>
<input type="text" class="form-control"  name="Correo" value = "<?php echo e(isset($patrocinio->Correo)?$patrocinio->Correo:''); ?>">
<br> 
<label for="Telefono"> Telefono:</label>
<input type="text" class="form-control"  name= "Telefono" value= "<?php echo e(isset($patrocinio->Telefono)?$patrocinio->Telefono:''); ?>">
  <br>  
  <br> 
<label for="Direccion"> Direccion:</label>
<input type="text" class="form-control"  name= "Direccion" value= "<?php echo e(isset($patrocinio->Direccion)?$patrocinio->Direccion:''); ?>">
  <br>
  <br> 
<label for="Presentacion"> Presentacion:</label>
<input type="text" class="form-control"  name= "Presentacion" value= "<?php echo e(isset($patrocinio->Presentacion)?$patrocinio->Presentacion:''); ?>">
  <br> 


  <input type="submit" class="btn btn-success" value="Enviar">
</div>
<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/patrocinio/form.blade.php ENDPATH**/ ?>