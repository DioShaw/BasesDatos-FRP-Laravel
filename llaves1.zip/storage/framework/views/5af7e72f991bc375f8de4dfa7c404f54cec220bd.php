
<?php if(count($errors)>0): ?>
<div class="alert alert-danger" role="alert">

<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

    </ul>
</div>

<?php endif; ?>


<div class="form-group">
<label for="nombre"> Caja de compensacion :</label>
<input type="text"class="form-control" name="nombre" value="<?php echo e(isset($asocaja->Nombre)? $asocaja->Nombre:''); ?>" id="nombre">
</div>

<div class="form-group">
<label for="Departamento"> Departamento:</label>
<input type="text" class="form-control" name= "departamento" value="<?php echo e(isset($asocaja->Departamento)?$asocaja->Departamento:''); ?>">
</div>


<label for="director"> director:</label>
<input type="text" class="form-control" name= "director" value="<?php echo e(isset($asocaja->Director)?$asocaja->Director:''); ?>">


<label for="telefono"> telefono:</label>
<input type="text" class="form-control" name= "telefono" value= "<?php echo e(isset($asocaja->Telefono)?$asocaja->Telefono:''); ?>">

<label for="direccion"> direccion:</label>
<input type="text" class="form-control" name="direccion" value = "<?php echo e(isset($asocaja->Direccion)?$asocaja->Direccion:''); ?>">

<label for="correo"> Correo:</label>
<input type="text" class="form-control" name="correo" value="<?php echo e(isset($asocaja->Correo)?$asocaja->Correo:''); ?>">
<br>

<input type="submit" class="btn btn-success" value="Enviar">
</div>





<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/asocaja/form.blade.php ENDPATH**/ ?>