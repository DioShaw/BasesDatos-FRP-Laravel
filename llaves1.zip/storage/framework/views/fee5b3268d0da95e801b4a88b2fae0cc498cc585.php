<?php if(count($errors)>0): ?>

<div class="alert alert-danger" role="alert">
<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>                                                           
</div>

<?php endif; ?>


<div class="form-group">

<label for="nombre"> Nombres:</label>
<input type="text" class="form-control"  name="Nombre" value="<?php echo e(isset($filbo_artista->Nombre)? $filbo_artista->Nombre:''); ?>" id="Nombre">
</div>

<label for="Perfil"> Perfil:</label>
<input type="text" class="form-control"  name="perfil" value="<?php echo e(isset($filbo_artista->Perfil)?$filbo_artista->Perfil:''); ?>" id="Perfil">
<br>
<label for="director"> Organizacion:</label>
<input type="text" class="form-control"  name= "organizacion" value="<?php echo e(isset($filbo_artista->Organizavion)?$filbo_artista->Organizacion:''); ?>">
<br>
<label for="contacto"> Agenda:</label>
<input type="text" class="form-control"  name="agenda" value="<?php echo e(isset($filbo_artista -> Agenda)?$filbo_artista-> Agenda:''); ?>">
<br>
<label for="telefono"> Telefono:</label>
<input type="text" class="form-control"  name= "telefono" value= "<?php echo e(isset($filbo_artista->Telefono)?$filbo_artista->Telefono:''); ?>">
  <br>  
<label for="direccion"> Correo:</label>
<input type="text" class="form-control"  name="correo" value = "<?php echo e(isset($filbo_artista->Correo)?$filbo_artista->Correo:''); ?>">
<br>  
<br>  

<input type="submit" class="btn btn-success" value="Enviar">
</div>

<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/filbo_artista/form.blade.php ENDPATH**/ ?>