
<?php if(count($errors)>0): ?>

<div class="alert alert-danger" role="alert">
<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>



<?php endif; ?>


<div class="form-group">

<label for="nombre"> Nombres:</label>
<input type="text" class="form-control"  name="nombres" value="<?php echo e(isset($tallerista->Nombres)? $tallerista->Nombres:''); ?>" id="nombres">
</div>

<label for="celular"> Celular:</label>
<input type="text" class="form-control"  name="telefono" value="<?php echo e(isset($tallerista->Telefono)?$tallerista->Telefono:''); ?>" id="telefono">
<br>
<label for="correo"> Correo:</label>
<input type="text" class="form-control"  name= "correo" value="<?php echo e(isset($tallerista->Correo)?$tallerista->Correo:''); ?>">
<br>
<label for="cargo"> Cargo:</label>
<input type="text" class="form-control"  name="cargo" value="<?php echo e(isset($tallerista -> Cargo)?$tallerista-> Cargo:''); ?>">

<br>

<input type="submit" class="btn btn-success" value="Enviar">
</div>

<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/tallerista/form.blade.php ENDPATH**/ ?>