
<?php if(count($errors)>0): ?>

<div class="alert alert-danger" role="alert">
<ul>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li> <?php echo e($error); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>



<?php endif; ?>


<div class="form-group">

<label for="nombre"> Nombres:</label>
<input type="text" class="form-control"  name="nombres" value="<?php echo e(isset($practicante->nombres)? $practicante->nombres:''); ?>" id="nombres">
</div>



<label for="Nit"> Celular:</label>
<input type="text" class="form-control"  name="telefono" value="<?php echo e(isset($practicante->telefono)?$practicante->telefono:''); ?>" id="telefono">
<br>
<label for="director"> Correo:</label>
<input type="text" class="form-control"  name= "correo" value="<?php echo e(isset($practicante->correo)?$practicante->correo:''); ?>">
<br>
<label for="contacto"> Cargo:</label>
<input type="text" class="form-control"  name="cargo" value="<?php echo e(isset($practicante -> cargo)?$practicante-> cargo:''); ?>">
<br>
<label for="telefono"> Generacion:</label>
<input type="text" class="form-control"  name= "generacion" value= "<?php echo e(isset($Practicante->generacion)?$Practicante->generacion:''); ?>">
  <br>  
<label for="direccion"> Ingreso:</label>
<input type="text" class="form-control"  name="ingreso" value = "<?php echo e(isset($Practicante->direccion)?$Practicante->ingreso:''); ?>">
<br>  
<label for="estado"> Estado:</label>
<input type="text" class="form-control"  name="estado" value="<?php echo e(isset($Practicante->estado)?$Practicante->estado:''); ?>">
<br>  

<input type="submit" class="btn btn-success" value="Enviar">

</div>

<?php /**PATH C:\xampp\htdocs\llaves1\resources\views/practicante/form.blade.php ENDPATH**/ ?>