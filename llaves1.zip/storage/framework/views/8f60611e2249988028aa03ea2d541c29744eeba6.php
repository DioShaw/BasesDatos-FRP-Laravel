

<?php $__env->startSection('content'); ?>
<head>
<link href="<?php echo e(asset('css/menu.css')); ?>" rel = "stylesheet">
</head>

<div class="container">

<?php if(Session::has('mensaje')): ?>
<div class="alert alert-soucess alert-dismissible" role="alert" id="mensajeeditar">
<?php echo e(Session::get('mensaje')); ?>

<button type="button" class="close" data-dismiss="alet" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<?php endif; ?>

<div class="grid-container">

<div class="grid-item"><form action="http://localhost/llaves1/public/patrocinio/create/"> <button id="btn-crear" class="linea" type="submit">Crear Nuevo</button></form></div>

</div>

<table class="table table-light">
    <thead class="thead-light">
        <tr>
            <th>Empresa</th>
            <th>Nombre</th>
            <th>Cargo</th>
            <th>Tema</th>
            <th>Contacto</th>
            <th>Correo</th>
            <th>Telefono</th>
            <th>Direccion</th>
            <th>Presentacion</th>
           <th>Acciones</th>
         
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $patrocinios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patrocinio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($patrocinio->Empresa); ?></td>
            <td><?php echo e($patrocinio->Nombre); ?></td>
            <td><?php echo e($patrocinio->Cargo); ?></td>
            <td><?php echo e($patrocinio->Tema); ?></td>
            <td><?php echo e($patrocinio->Contacto); ?></td>
            <td><?php echo e($patrocinio->Correo); ?></td>
            <td><?php echo e($patrocinio->Telefono); ?></td>
            <td><?php echo e($patrocinio->Direccion); ?></td>
            <td><?php echo e($patrocinio->Presentacion); ?></td>
       
            <td> 
            
            <a href="<?php echo e(url('/patrocinio/'.$patrocinio->id.'/edit')); ?> " class="btn btn-warning">
                Editar
            </a>
            <form action="<?php echo e(url('/patrocinio/'.$patrocinio->id)); ?>" class="d-inline" method="post" >
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

                <input class="btn btn-danger " type="submit" onclick="return confirm('confirma')"
                 value="Borrar">
            </form>
            
            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\llaves1\resources\views/patrocinio/index.blade.php ENDPATH**/ ?>