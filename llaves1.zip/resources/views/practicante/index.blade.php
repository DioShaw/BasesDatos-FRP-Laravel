@extends('layouts.app')

@section('content')
<head>
<link href="{{ asset('css/menu.css') }}" rel = "stylesheet">
</head>

<div class="container">

@if (Session::has('mensaje'))
<div class="alert alert-soucess alert-dismissible" role="alert" id="mensajeeditar">
{{ Session::get('mensaje') }}
<button type="button" class="close" data-dismiss="alet" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif


<div class="grid-container">
<div class="grid-item"><form action="http://localhost/llaves1/public/practicante/create/"> <button id="btn-crear" class="linea" type="submit">Crear Nuevo</button></form></div>
</div>


<table class="table table-light">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombres</th>
            <th>Telefono</th>
            <th>Correo</th>
            <th>Cargo</th>
            <th>Generacion</th>
            <th>Ingreso</th>
            <th>Ingreso</th>
        </tr>
    </thead>
    <tbody>
    @foreach( $practicantes as $practicante)
        <tr>
            <td>{{$practicante->id}}</td>
            <td>{{$practicante->nombres}}</td>
            <td>{{$practicante->telefono}}</td>
            <td>{{$practicante->correo}}</td>
            <td>{{$practicante->cargo}}</td>
            <td>{{$practicante->generacion}}</td>
            <td>{{$practicante->ingreso}}</td>
            <td> 
            <a href="{{url('/practicante/'.$practicante->id.'/edit')}}" class="btn btn-warning" >  Editar </a>
            \
            <form action="{{ url('/practicante/'.$practicante->id) }}" class="d-inline" method="post" >
            @csrf
            {{method_field('DELETE')}}
            <input class="btn btn-danger " type="submit" onclick="return confirm('confirma')"
                 value="Borrar">
            </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

</div>
@endsection