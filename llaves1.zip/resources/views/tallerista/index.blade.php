@extends('layouts.app')

@section('content')
<head>
<link href="{{ asset('css/menu.css') }}" rel = "stylesheet">
</head>

<div class="container">

@if (Session::has('mensaje'))
<div class="alert alert-soucess alert-dismissible" role="alert" id="mensajeeditar">
{{ Session::get('mensaje') }}
<button type="button" class="close" data-dismiss="alet" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif

<div class="grid-container">

<div class="grid-item"><form action="http://localhost/llaves1/public/tallerista/create/"> <button id="btn-crear" class="linea" type="submit">Crear Nuevo</button></form></div>

</div>

<table class="table table-light">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Nombres</th>
            <th>Telefono</th>
            <th>Correo</th>
            <th>Cargo</th>
        </tr>
    </thead>
    <tbody>
    @foreach( $talleristas as $tallerista)
        <tr>
            <td>{{$tallerista->id}}</td>
            <td>{{$tallerista->Nombres}}</td>
            <td>{{$tallerista->Telefono}}</td>
            <td>{{$tallerista->Correo}}</td>
            <td>{{$tallerista->Cargo}}</td>
    
            <td> 
            <a href="{{url('/tallerista/'.$tallerista->id.'/edit')}}" class="btn btn-warning" >  Editar </a>
            /
            <form action="{{ url('/tallerista/'.$tallerista->id) }}" class="d-inline" method="post" >
            @csrf
            {{method_field('DELETE')}}
            <input class="btn btn-danger " type="submit" onclick="return confirm('confirma')"
                 value="Borrar">
            </form>
            
            </td>

        </tr>
        @endforeach
    </tbody>
</table>

</div>
@endsection